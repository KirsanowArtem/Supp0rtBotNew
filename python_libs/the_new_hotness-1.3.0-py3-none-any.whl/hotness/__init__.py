"""
the-new-hotness - Perform actions based on new releases detected by Anitya.
"""
from __future__ import absolute_import, unicode_literals
from importlib import metadata


__author__ = "Red Hat, Inc. and others"
__license__ = "LGPLv2+"
__version__ = metadata.version("the-new-hotness")
